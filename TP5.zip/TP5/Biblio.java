/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP5;

import java.util.*;

public class Biblio {
    Hashtable <String,livre > etagers = new Hashtable<String,livre>(); ;
    
    void Biblio()
    {
        livre liv =null ;
        etagers.put("haute",liv);
        etagers.put("milieu",liv);
        etagers.put("base",liv);
    }
    
    public void ajoutelivre(String niveaux,livre liv)
    {
        if(niveaux == "haute" || niveaux == "milieu" || niveaux == "base")
        {
            etagers.put(niveaux,liv);
        }
        else System.out.println("il'ya 3 type haute , milieux ,base");
    }
    
    public void retirelivre(String niveaux,String titre,String auteur)
    {
        Etagere e = null ;
        Enumeration<String> keys = etagers.keys();
        while (keys.hasMoreElements()) {
        String key = keys.nextElement();
        livre liv = etagers.get(key);
        if(key==niveaux && liv.getAuteur() == auteur && liv.getTitre() == titre)
        {
            etagers.remove(key);
        }
        
        }
       
    }
    
    public void retirelivre(livre liv)
    {
        Etagere e = null ;
        Enumeration<String> keys = etagers.keys();
        while(keys.hasMoreElements()) {
        String key = keys.nextElement();
        livre l = etagers.get(key);
        if(l==liv)
        {
            etagers.remove(key);
        }
        
        else System.out.println("votre livre est non connue");
        
        }
       
    }
    
    public int nombrelivres()
    {
        int n_1 = 0;int n_2 = 0;int n_3 = 0;
        Etagere e = null ;
        Enumeration<String> keys = etagers.keys();
        while (keys.hasMoreElements()) {
        String key = keys.nextElement();
        if(key=="haute")
        {
            n_1 = e.nombreLivre();
        }
        else if(key=="milieu")
        {
            n_2 = e.nombreLivre();
        }
        else if(key=="base")
        {
            n_3 = e.nombreLivre();
        }
        
        }
         return n_1+n_2+n_3 ;
    }
    
        public boolean estPresent(livre liv)
    {
        boolean a = false ;
        Etagere e = null ;
        Enumeration<String> keys = etagers.keys();
        while (keys.hasMoreElements()) {
        String key = keys.nextElement();
        livre l = etagers.get(key);
        if(l==liv) a= true;
        else a = false ;
        
        }
       return a ;
    }
      
     public void Tostring()
        {
        Enumeration<String> keys =etagers.keys();
        while (keys.hasMoreElements()) {
        String key = keys.nextElement();
        livre liv  = etagers.get(key);
        System.out.println(key + " : " +liv.getAuteur()+" "+" "+liv.getTitre()+" "+liv.getIsbn());
        }
        }
}

