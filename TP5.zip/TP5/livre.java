/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP5;

/**
 *
 * @author zahrouni
 */
public class livre {
    private String titre ,Auteur ;
    private int isbn ;
    private String [] T = new String[0];
        private void inserAuteur(String aut)
    {
        int i  ;
        String[] t1 = new String[T.length+1];
        for(i=0;i<T.length;i++)
        {
            t1[i]=T[i];
        }
        t1[T.length]=aut;
        T=t1;
    }
        
    public livre(String titre,String Auteur,int isbn)
    {
        this.titre =titre ;
        this.Auteur = Auteur ;
        this.isbn = isbn ;
        inserAuteur(Auteur);
    }
    
    public String getTitre()
    {
        return titre ;
    }
    public String getAuteur()
    {
        return Auteur ;
    }
    public int getIsbn()
    {
        return isbn ;
    }
    
    public void Tostring()
    {
        System.out.println(titre+" "+Auteur+" "+isbn);
    }
    
    public boolean egal(livre l1 ,livre l2)
    {
        if(l1.getIsbn()==l2.getIsbn())
        {
            return true;
        }
        
        else return false ;
    }
    
}
