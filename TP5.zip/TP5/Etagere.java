/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP5;

import java.util.*;
       
public class Etagere {
    Vector <livre> livres = new Vector<livre>();
    
    public Etagere()
    {
        
    }
    public void ajouterlivre(livre l)
    {
        livres.add(l);
    }
    public void retirelivre(String titre ,String auteur)
    {
        for(int i=0;i<livres.size();i++)
        {
            livre l = livres.get(i);
            if(l.getAuteur()==auteur && l.getTitre()==titre)
            {
                        livres.remove(i);
            }
        }
    }
        public void retirelivre(livre liv)
    {
        for(int i=0;i<livres.size();i++)
        {
            livre l = livres.get(i);
            if(l == liv)
            {
                        livres.remove(i);
            }
        }
    }
        
       public livre getlivre(int pos)
    {
       return livres.get(pos);
    }
       public int nombreLivre()
       {
           return livres.size();
       }
       
       public void Tostring()
       {
           Enumeration<livre> l = livres.elements();
            while (l.hasMoreElements()) {
            livre ls = l.nextElement();
            System.out.println(ls.getAuteur()+" "+" "+ls.getTitre()+" "+ls.getIsbn());
                }
       }
       public boolean estPresent(livre liv)
       {
           boolean a = false ;  
            for(int i=0;i<livres.size();i++)
        {
            livre l = livres.get(i);
            if(l == liv) a = true;
            else a = false ;
        }
        return false;
       }
             
}
