
package TP5;


public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Biblio B = new Biblio();
        livre l_1 = new livre("java","karim",282);
        livre l_2 = new livre("c","aymen",772);
        livre l_3 = new livre("c++","ahmed",782);
        livre l_4 = new livre("python","karim",282);
        Etagere e = new Etagere();
        e.ajouterlivre(l_1);
        B.ajoutelivre("haute",l_1);
         B.ajoutelivre("base",l_2);
          B.ajoutelivre("milieu",l_3);

        l_1.Tostring();
        B.Tostring();
        B.retirelivre(l_1);
        B.retirelivre("base", "c", "aymen");
        B.Tostring();
        
    }
    
}
